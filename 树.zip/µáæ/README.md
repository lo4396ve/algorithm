# 树
## 1、概念
树是一种数据结构，它是由n(n>=1)个有限节点组成一个具有层次关系的集合。把它叫做“树”是因为它看起来像一棵倒挂的树，也就是说它是根朝上，而叶朝下的。
![image](./images/tree.png);
#### 1.1 节点
每个元素称为节点（node），节点包含数据项，和指向其他节点的指针。
#### 1.2 节点的度
一个节点含有的子节点的个数称为该节点的度。上图示例中节点1的度是三，节点2的度是二，节点4的度是一，节点3、节点5、节点6、节点7的度是零。

#### 1.3 叶节点
度为0的节点被成为叶节点，如上图中的3、5、6、7

#### 1.4 分支节点
除了叶节点其的都是分支节点，如上图中1、3、4

#### 1.5 子节点
一个节点含有的子树的根节点称为该节点的子节点。也叫子女节点或者叫孩子节点

#### 1.6 父节点
若一个节点含有子节点，则这个节点称为其子节点的父节点

#### 1.7 兄弟节点
具有相同父节点的节点互称为兄弟节点

#### 1.8 堂兄弟节点
父节点在同一层的节点互为堂兄弟

#### 1.9 祖先节点
从根到该节点所经分支上的所有节点，都是该节点的祖先节点

#### 1.10 子孙节点
以某节点为根的子树中任一节点都称为该节点的子孙节点

#### 1.11 节点的层次
从根开始定义起，根为第1层，根的子节点为第2层，以此类推

#### 1.12 树的深度
对于任意节点n,n的深度为从根到n的唯一路径长，根的深度为0

#### 1.13 树的高度
对于任意节点n,n的高度为从n到一片树叶的最长路径长，所有树叶的高度为0

#### 1.14 树的度
一棵树中，最大的节点度称为树的度

#### 1.15 树的边
树的边等于总节点数减一，也等于每个节点的度之和。

#### 1.16 森林
由m（m>=0）棵互不相交的树的集合称为森林


## 2、二叉树
### 2.1 概念
每个节点最多含有两个子树的树称为二叉树。
二叉树是最常用的树形结构，也是重点研究对象。
![iamge](./images/towTree.png)

### 2.2 二叉树的特点
* 在二叉树的第i(i>=1)层，最多有2i-1 个节点。
* 深度为k(k>=0)的二叉树，最少有k个节点，最多有2^k -1 个节点。
* 对于一棵非空二叉树，叶节点的数量等于度为2的节点数量加1。

>叶节点的数量与度为2的节点数量关系证明：
再引入“边”的概念
观察上图中的树，设总结点数为N，叶节点（度为0）的数量为N0，度为1的节点数量为N1，度为2的节点数量为N2，则有以下公式：
N = N0 + N1 + N2;（公式1）
根据树的边的定义设树的边B，则有
B = N - 1;（公式2）
B = 0\*N0 + 1\*N1 + 2\*N2 = N1 + 2\*N2; （公式3）
把公式1代入公式2：
B = N0 + N1 + N2 - 1; （公式4）
把公式4代入公式3：
N0 + N1 + N2 - 1 = N1 + 2\*N2;
N0 = N2 + 1;

### 2.3 特殊二叉树
#### 2.3.1 满二叉树
深度为k的满二叉树，有2k-1 个节点，每一层都达到了可以容纳的最大数量的节点
![image](./images/fullTree.png)

#### 2.3.2 完全二叉树
一棵深度为k的有n个结点的二叉树，对树中的结点按从上至下、从左到右的顺序进行编号，如果编号为i（1≤i≤n）的结点与满二叉树中编号为i的结点在二叉树中的位置相同，则这棵二叉树称为完全二叉树。

**性质：**

* 具有n个结点的完全二叉树的深度（注：[ ]表示向下取整）
* 如果对一棵有n个结点的完全二叉树的结点按层序编号, 则对任一结点i (1≤i≤n) 有:
  * 如果i=1, 则结点i是二叉树的根, 无双亲;如果i>1, 则其双亲parent (i) 是结点[i/2].
  * 如果2i>n, 则结点i无左孩子, 否则其左孩子lchild (i) 是结点2i;
  * 如果2i+1>n, 则结点i无右孩子, 否则其右孩子rchild (i) 是结点2i+1

**特点：**

完全二叉树的特点：叶子结点只能出现在最下层和次下层，且最下层的叶子结点集中在树的左部。需要注意的是，满二叉树肯定是完全二叉树，而完全二叉树不一定是满二叉树。
![image](./images/wanquanTree.png)

**判断条件**
1. 如果树为空，直接返回false
2. 如果不为空，层序遍历树
3. 如果一个结点左右孩子都不为空，则pop该节点，将其左右孩子入队列
4. 如果遇到一个结点，左孩子为空，右孩子不为空，则该树一定不是完全二叉树，返回false
5. 如果遇到一个结点，左孩子不为空，右孩子为空；或者左右孩子都为空；则该节点之后的队列中的结点都为叶子节点；该树才是完全二叉树，否则就不是完全二叉树


### 2.4 定义二叉树
#### 2.4.1 节点
```
function TreeNode(data) {
  this.data = data;
  this.leftChild = null;    // 左孩子
  this.rightChild = null;   // 右孩子
  this.parentNode = null;   // 父节点
}
```
#### 2.4.2 树类
根据[广义表](https://baike.baidu.com/item/%E5%B9%BF%E4%B9%89%E8%A1%A8/3685109?fr=aladdin)来创建树，比如A(B(D,E),C(F))#代表如下树结构：
![image](./images/demo1.png)
**算法：**
联想到如何用栈校验括号的合法性，借助该算法，可以利用栈帮助创建树。
1. 遍历广义表字符串，遇到字母则创建节点
2. 遇到左括号，说明之前存在一个节点，把该节点入栈，而且括号里面的节点是它的子节点，但是需要区分是左子节点还是右子节点，需要根据第三步逗号出现的时机判断左右
3. 在遇到逗号出现之前被认为是左子节点，在遇到逗号之后是右子节点
4. 遇到右括号说明该子树结束了，而且栈顶就是该子树的根节点，执行pop方法出栈。

```
function Tree() {
  var root = null;   // 根节点
  this.getRoot = function() {
    return root;
  }
  this.initTree = function(string) {
    let stack = new Stack();
    let new_node = null;  // 记录每次遇到字母创建的节点
    let k = 0;  // k初始值设为0，k=1代表左子节点，k=2代表右子节点
    for(let i = 0; i < string.length; i++) {
      let item = string[i];
      if(item == '(') {
        stock.push(new_node);
        k = 1;
      }
      else if(item == ',') {
        k = 2;
      } else if(item == ')') {
        stock.pop();
      } else {
        // 遇到字母
        new_node = new TreeNode(item);
        if(!root) {
          // 如果跟节点不存在 说明是第一个字母
          root = new_node;
        }
        if(k == 1) {
          // 左子节点
          father = stock.top(); // 栈顶一定是该子节点的父节点
          father.leftChild = new_node;
          new_node.parentNode = father;
        } 
        else if (k == 2) {
          // 右子节点
          father = stock.top(); // 栈顶一定是该子节点的父节点
          father.rightChild = new_node;
          new_node.parentNode = father;
        }
      }
    }
  }
}
```

### 2.5 方法扩展
树的遍历包括前序遍历(父节点->左子节点->右子节点)、中序遍历(左子节点->父节点->右子节点)、后序遍历(左子节点->右子节点->父节点)和层序遍历(逐层遍历)。
#### 2.5.1 前序遍历
对树的遍历非常适合使用递归，因为每一个子树都是一个完整的树结构。
前序遍历：父节点->左子节点->右子节点
```
this.pre_order = function(node){
    if(node==null){
        return;
    }
    console.log(node.data);
    this.pre_order(node.leftChild);
    this.pre_order(node.rightChild);
};
```

#### 2.5.2 中序遍历
中序遍历：左子节点->父节点->右子节点
```
this.in_order = function(node){
    if(node==null){
        return;
    }
    this.in_order(node.leftChild);
    console.log(node.data);
    this.in_order(node.rightChild);
};
```

#### 2.5.3 后序遍历
```
this.post_order = function(node){
    if(node==null){
        return;
    }
    this.post_order(node.leftChild);
    this.post_order(node.rightChild);
    console.log(node.data);
};
```

#### 2.5.4 层序遍历
层序遍历可以借助队列
1. 把根节点添加到队列
2. 判断是否有子节点，如果有把子节点添加到队列末尾
3. 遍历过的节点出队列
4. 直到队列为空

```
this.layer_order = function(node) {
  let queue = new Queue();
  
  queue.enqueue(node);
  while(!queue.isEmpty()) {
    let curNode = queue.head();
    console.log(curNode.data);
    if(curNode.leftChild) {
      queue.enqueue(curNode.leftChild);
    }
    if(curNode.rightChild) {
      queue.enqueue(curNode.rightChild);
    }
    curNode = queue.dequeue();
  }
}
```

完整代码：
```

```




