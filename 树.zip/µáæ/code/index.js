function Stack() {
  var items = [];  // 使用数组存储数据

  // push方法向栈里压入一个元素
  this.push = function(item){
      items.push(item);
  };

  // pop方法把栈顶的元素弹出
  this.pop = function(){
      return items.pop();
  };

  // top 方法返回栈顶元素
  this.top = function(){
      return items[items.length - 1];
  };

  // isEmpty返回栈是否为空
  this.isEmpty = function(){
      return items.length == 0;
  };

  // size方法返回栈的大小
  this.size = function(){
      return items.length;
  };

  // clear 清空栈
  this.clear = function(){
      items = []
  }
}
function Queue(){
  var items = [];   // 存储数据

  // 向队列尾部添加一个元素
  this.enqueue = function(item){
      items.push(item);
  };

  // 移除队列头部的元素
  this.dequeue = function(){
      return items.shift();
  };

  // 返回队列头部的元素
  this.head = function(){
      return items[0];
  }

  // 返回队列大小
  this.size = function(){
      return items.length;
  }

  // clear
  this.clear = function(){
      items = [];
  }

  // isEmpty 判断是否为空队列
  this.isEmpty = function(){
      return items.length == 0;
  }
};

function TreeNode(data) {
  this.data = data;
  this.leftChild = null;    // 左孩子
  this.rightChild = null;   // 右孩子
  this.parentNode = null;   // 父节点
}

function Tree() {
  var root = null;   // 根节点
  this.getRoot = function() {
    return root;
  }
  this.init_tree = function(string) {
    let stack = new Stack();
    let new_node = null;  // 记录每次遇到字母创建的节点
    let k = 0;  // k初始值设为0，k=1代表左子节点，k=2代表右子节点
    for(let i = 0; i < string.length; i++) {
      let item = string[i];
      if(item == '(') {
        stack.push(new_node);
        k = 1;
      }
      else if(item == ',') {
        k = 2;
      } else if(item == ')') {
        stack.pop();
      } else {
        // 遇到字母
        new_node = new TreeNode(item);
        if(!root) {
          // 如果跟节点不存在 说明是第一个字母
          root = new_node;
        }
        if(k == 1) {
          // 左子节点
          father = stack.top(); // 栈顶一定是该子节点的父节点
          father.leftChild = new_node;
          new_node.parentNode = father;
        } 
        else if (k == 2) {
          // 右子节点
          father = stack.top(); // 栈顶一定是该子节点的父节点
          father.rightChild = new_node;
          new_node.parentNode = father;
        }
      }
    }
  }
}

// 中序遍历
function in_order(node) {
  if(!node) {
    return ;
  }
  in_order(node.leftChild);
  console.log(node.data);
  in_order(node.rightChild);
  
}
function layer_order(node) {
  let queue = new Queue();
  
  queue.enqueue(node);
  while(!queue.isEmpty()) {
    let curNode = queue.head();
    console.log(curNode.data);
    if(curNode.leftChild) {
      queue.enqueue(curNode.leftChild);
    }
    if(curNode.rightChild) {
      queue.enqueue(curNode.rightChild);
    }
    curNode = queue.dequeue();
  }
}
let tree = new Tree();
tree.init_tree("A(B(D,E),C(F))");
let root = tree.getRoot();
// in_order(root);
layer_order(root);